function solve(city, population, treasury) {
    const result = {
        name: city,
        population,
        treasury,
    }

    return result;
}

solve('Tortuga',
    7000,
    15000
);
