console.log('External JS');

let headingElement = document.querySelector('h1');
console.log(headingElement);
