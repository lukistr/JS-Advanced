function showText() {
    let moreTextElement = document.getElementById('text');
    let moreButtonElement = document.getElementById('more');

    moreTextElement.style.display = '';
    moreButtonElement.style.display = 'none';
}
