const calc = require('./commonJS-calculator.cjs');

console.log(calc(10, 20));
