import { sum } from "./sum.js";

console.log(sum('123123'));
