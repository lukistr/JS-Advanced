import { sum } from './calculator.js';

console.log(sum(1, 2));
