function calculator(a, b) {
    return a + b;
}

// Default export
module.exports = calculator;
