import calc, { mult, sum } from './calculator.mjs';
// import calc from './calculator.mjs';
import * as calculator from './calculator.mjs';

console.log(calc.sum(10, 20));
console.log(sum(10, 20));
console.log(mult(10, 20));
console.log(calculator.sum(1, 2));
