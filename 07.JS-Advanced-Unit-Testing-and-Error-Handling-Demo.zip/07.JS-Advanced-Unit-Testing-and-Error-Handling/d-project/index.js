// const {func} = require('calculator');
import { func } from 'calculator';

var f = func('f(x) = x*10 - 20');
console.log(f(3)); //returns 10
