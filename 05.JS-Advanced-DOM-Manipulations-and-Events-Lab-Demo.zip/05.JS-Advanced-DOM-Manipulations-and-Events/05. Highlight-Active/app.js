function focused() {
    console.log('TODO:...');
}