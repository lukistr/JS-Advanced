let message = 'Hello wolrd!';

console.log(message);
