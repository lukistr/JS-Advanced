function echo(text) {
    console.log(text.length);
    console.log(text);
}

echo('Hello, JavaScript!');
